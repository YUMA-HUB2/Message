import java.util.ArrayList;
import java.util.List;
import java.util.Collections; // Used for finding the longest message

/**
 * The main application class handling data storage and manipulation.
 */
public class MessageApp {

    // 1. Global Arrays (ArrayLists) to store message objects and extracted data
    private List<Message> allMessages = new ArrayList<>();
    private List<Message> sentMessages = new ArrayList<>();
    private List<Message> disregardedMessages = new ArrayList<>();
    private List<Message> storedMessages = new ArrayList<>();
    private List<String> messageHashes = new ArrayList<>();
    private List<String> messageIDs = new ArrayList<>();

    // --- Data Population and Loading ---

    public void addMessage(Message message) {
        allMessages.add(message);
        messageHashes.add(message.getHash());
        messageIDs.add(message.getId());

        String flag = message.getFlag();
        if ("Sent".equals(flag)) {
            sentMessages.add(message);
        } else if ("Disregard".equals(flag)) {
            disregardedMessages.add(message);
        } else if ("Stored".equals(flag)) {
            storedMessages.add(message);
        }
    }

    // Mock function for JSON reading requirement
    public void readJsonStoredMessages(String filename) {
        // This function would typically use a library like Jackson or GSON to parse JSON.
        // For example:
        /*
        try (FileReader reader = new FileReader(filename)) {
            // ObjectMapper mapper = new ObjectMapper(); // if using Jackson
            // Message[] storedArray = mapper.readValue(reader, Message[].class);
            // for (Message msg : storedArray) {
            //     addMessage(msg); 
            // }
        } catch (Exception e) {
            System.out.println("Error reading JSON file: " + e.getMessage());
        }
        */
        // Since we cannot implement actual JSON parsing here, we rely on the test data loader.
        System.out.println("JSON file reading simulated. Relying on test data for content.");
    }
    
    public void loadTestData() {
        // Message 1 (Sent)
        addMessage(new Message("+27834557896", "Did you get the cake?", "Sent", null));
        // Message 2 (Stored)
        addMessage(new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored", null));
        // Message 3 (Disregard)
        addMessage(new Message("+27834484567", "Yohoooo, I am at your gate.", "Disregard", null));
        // Message 4 (Sent) - Developer ID provided
        addMessage(new Message("0838884567", "It is dinner time !", "Sent", "0838884567"));
        // Message 5 (Stored)
        addMessage(new Message("+27838884567", "Ok, I am leaving without you.", "Stored", null));
    }
    
    // --- Accessor Methods for Testing (Getters) ---
    public List<Message> getSentMessages() { return sentMessages; }
    public List<Message> getStoredMessages() { return storedMessages; }
    public List<String> getMessageHashes() { return messageHashes; }
    public List<String> getMessageIDs() { return messageIDs; }

    // --- 2. Required Functionality ---

    /**
     * 2a. Displays the sender (ID) and recipient of all sent messages.
     */
    public List<String> displaySentMessagesSendersRecipients() {
        List<String> report = new ArrayList<>();
        for (Message msg : sentMessages) {
            report.add("ID: " + msg.getId() + ", Recipient: " + msg.getRecipient());
        }
        return report;
    }

    /**
     * 2b. Displays the longest message overall (to match the test requirement).
     */
    public String displayLongestMessage() {
        if (allMessages.isEmpty()) {
            return "No messages available.";
        }
        // Find the message object with the longest content string length
        Message longest = Collections.max(allMessages, (m1, m2) -> Integer.compare(
            m1.getContent().length(), m2.getContent().length()
        ));
        return longest.getContent();
    }

    /**
     * 2c. Searches for a message ID and displays the corresponding recipient and message.
     */
    public String searchMessageById(String messageId) {
        for (Message msg : allMessages) {
            if (msg.getId().equals(messageId)) {
                return "Recipient: " + msg.getRecipient() + ", Message: '" + msg.getContent() + "'";
            }
        }
        return "Message ID " + messageId + " not found.";
    }

    /**
     * 2d. Searches for all the messages sent or stored regarding a particular recipient.
     */
    public List<String> searchMessagesByRecipient(String recipient) {
        List<String> results = new ArrayList<>();
        for (Message msg : allMessages) {
            if (msg.getRecipient().equals(recipient)) {
                results.add(msg.getContent());
            }
        }
        return results;
    }

    /**
     * 2e. Deletes a message using the message hash.
     */
    public String deleteMessageByHash(String messageHash) {
        Message messageToDelete = null;

        // 1. Find the message object
        for (Message msg : allMessages) {
            if (msg.getHash().equals(messageHash)) {
                messageToDelete = msg;
                break;
            }
        }

        if (messageToDelete != null) {
            // 2. Remove from ALL_MESSAGES and extracted lists
            allMessages.remove(messageToDelete);
            messageHashes.remove(messageToDelete.getHash());
            messageIDs.remove(messageToDelete.getId());

            // 3. Remove from its status-specific list
            if (messageToDelete.getFlag().equals("Sent")) {
                sentMessages.remove(messageToDelete);
            } else if (messageToDelete.getFlag().equals("Disregard")) {
                disregardedMessages.remove(messageToDelete);
            } else if (messageToDelete.getFlag().equals("Stored")) {
                storedMessages.remove(messageToDelete);
            }

            return "Message '" + messageToDelete.getContent() + "' successfully deleted.";
        } else {
            return "Error: Message hash not found.";
        }
    }

    /**
     * 2f. Displays a report that lists the full details of all the sent messages.
     */
    public String displaySentMessagesReport() {
        StringBuilder report = new StringBuilder();
        report.append("--- SENT MESSAGES REPORT ---\n");
        for (Message msg : sentMessages) {
            report.append(msg.toString()).append("\n");
        }
        report.append("----------------------------");
        return report.toString();
    }
    
    // --- Main Method for Demo ---
    public static void main(String[] args) {
        MessageApp app = new MessageApp();
        app.loadTestData();
        app.readJsonStoredMessages("stored_messages.json");

        // The hash of Message 2 is needed for deletion test. Since hash is generated, we find it:
        String msg2Content = "Where are you? You are late! I have asked you to be on time.";
        String hashMsg2 = app.getAllMessages().stream()
            .filter(m -> m.getContent().equals(msg2Content))
            .map(Message::getHash)
            .findFirst().orElse("HASH_NOT_FOUND");


        System.out.println("--- Message App Demo (Java) ---\n");
        
        System.out.println("2a. Senders and Recipients of Sent Messages:");
        app.displaySentMessagesSendersRecipients().forEach(System.out::println);
        
        System.out.println("\n2b. Longest Message:");
        System.out.println("'" + app.displayLongestMessage() + "'");
        
        System.out.println("\n2c. Search by Message ID (0838884567):");
        System.out.println(app.searchMessageById("0838884567"));
        
        System.out.println("\n2d. Search by Recipient (+27838884567):");
        app.searchMessagesByRecipient("+27838884567").forEach(m -> System.out.println("'" + m + "'"));

        System.out.println("\n2f. Full Sent Messages Report:");
        System.out.println(app.displaySentMessagesReport());
        
        System.out.println("\n2e. Deleting Message 2 (Hash: " + hashMsg2 + "):");
        System.out.println(app.deleteMessageByHash(hashMsg2));
        
        System.out.println("\nVerification: STORED_MESSAGES count after deletion: " + app.getStoredMessages().size());
    }

    public List<Message> getAllMessages() {
        return allMessages;
    }
}
