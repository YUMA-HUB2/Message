import java.util.UUID;

/**
 * Represents a single message with all its properties.
 * This class handles and manipulates the message data.
 */
public class Message {
    private String hash;
    private String id; // Represents the sender/developer ID
    private String recipient;
    private String content;
    private String flag; // e.g., "Sent", "Stored", "Disregard"

    // Constructor
    public Message(String recipient, String content, String flag, String developerId) {
        // Use a simple, short UUID for the hash
        this.hash = UUID.randomUUID().toString().substring(0, 8); 
        // ID is the developer ID if provided, otherwise the recipient number (as sender)
        this.id = (developerId != null && !developerId.isEmpty()) ? developerId : recipient;
        this.recipient = recipient;
        this.content = content;
        this.flag = flag;
    }

    // Getters for accessing private fields
    public String getHash() { return hash; }
    public String getId() { return id; }
    public String getRecipient() { return recipient; }
    public String getContent() { return content; }
    public String getFlag() { return flag; }

    /**
     * Overridden toString() for easy reporting.
     */
    @Override
    public String toString() {
        return "Hash: " + hash + 
               ", ID: " + id + 
               ", Recipient: " + recipient + 
               ", Message: '" + content + 
               "', Flag: " + flag;
    }
}