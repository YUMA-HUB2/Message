
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the MessageApp functionality using JUnit 5.
 */
public class MessageAppTest {

    private MessageApp app;
    private String msg2Content = "Where are you? You are late! I have asked you to be on time.";
    private String hashMsg2;

    @BeforeEach
    void setUp() {
        app = new MessageApp();
        app.loadTestData(); // Load data before each test
        
        // Find the generated hash for Message 2 for the deletion test
        hashMsg2 = app.getAllMessages().stream()
            .filter(m -> m.getContent().equals(msg2Content))
            .map(Message::getHash)
            .findFirst().orElseThrow();
    }

    @Test
    void test1_sentMessagesArrayCorrectlyPopulated() {
        // Test Data: Developer entry for Test data for message 1-4
        // Expected: “Did you get the cake?”, “It is dinner time!”
        
        List<String> actualSentContents = app.getSentMessages().stream()
            .map(Message::getContent)
            .collect(Collectors.toList());
            
        List<String> expected = Arrays.asList(
            "Did you get the cake?", 
            "It is dinner time !"
        );
        
        // assertIterableEquals checks that both lists contain the same elements in the same order
        // assertLinesMatch is also a good option for unordered comparison
        assertTrue(actualSentContents.containsAll(expected) && expected.containsAll(actualSentContents), 
                   "Sent Messages array content is incorrect.");
    }

    @Test
    void test2_displayTheLongestMessage() {
        // Test Data: message 1-4
        // Expected: “Where are you? You are late!, I have asked you to be on time.” (Message 2, the longest overall)
        
        String actualLongest = app.displayLongestMessage();
        
        assertEquals(msg2Content, actualLongest, "Longest message search failed.");
    }

    @Test
    void test3_searchForMessageID() {
        // Test Data: message 4 ID: “0838884567”
        // Expected: ““It is dinner time!” 
        
        String testId = "0838884567";
        String expectedOutput = "Recipient: 0838884567, Message: 'It is dinner time !'";
        
        String actualResult = app.searchMessageById(testId);
        
        // Since the function returns a formatted string, we check the whole string.
        assertEquals(expectedOutput, actualResult, "Search by Message ID failed.");
    }

    @Test
    void test4_searchMessagesByRecipient() {
        // Test Data: +27838884567 (Recipient for Message 2 and 5)
        // Expected: “Where are you? You are late! I have asked you to be on time.”, “Ok, I am leaving without you.”
        
        String testRecipient = "+27838884567";
        List<String> expectedMessages = Arrays.asList(
            msg2Content, 
            "Ok, I am leaving without you."
        );
        
        List<String> actualMessages = app.searchMessagesByRecipient(testRecipient);
        
        // assertEquals checks content and order, but since search doesn't guarantee order, 
        // we use assertTrue with containsAll for robust testing.
        assertTrue(actualMessages.containsAll(expectedMessages) && expectedMessages.containsAll(actualMessages), 
                   "Search by Recipient failed to find all messages.");
    }

    @Test
    void test5_deleteMessageByHash() {
        // Test Data: Test Message 2 (using its hash)
        // Expected: Message “Where are you? You are late! I have asked you to be on time” successfully deleted.
        
        String expectedSuccessMessage = "Message '" + msg2Content + "' successfully deleted.";
        
        // 1. Check initial state
        int initialStoredSize = app.getStoredMessages().size(); // Should be 2 (Msg 2, Msg 5)
        
        // 2. Perform deletion
        String actualResult = app.deleteMessageByHash(hashMsg2);
        
        // 3. Check result message
        assertEquals(expectedSuccessMessage, actualResult, "Deletion result message is incorrect.");
        
        // 4. Check array state
        int finalStoredSize = app.getStoredMessages().size(); // Should be 1 (Msg 5)
        assertEquals(initialStoredSize - 1, finalStoredSize, "Message was not removed from StoredMessages array.");
    }

    @Test
    void test6_displayReport() {
        // Expected: A report showing details (Hash, Recipient, Message) for Message 1 and Message 4.
        
        String report = app.displaySentMessagesReport();
        
        // Check for report structure
        assertTrue(report.contains("--- SENT MESSAGES REPORT ---"), "Report header missing.");
        
        // Check for Message 1 content
        assertTrue(report.contains("Did you get the cake?"), "Report missing Message 1 content.");
        assertTrue(report.contains("Recipient: +27834557896"), "Report missing Message 1 recipient.");
        
        // Check for Message 4 content
        assertTrue(report.contains("It is dinner time !"), "Report missing Message 4 content.");
        assertTrue(report.contains("ID: 0838884567"), "Report missing Message 4 ID.");
    }
}